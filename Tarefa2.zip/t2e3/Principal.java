package tarefa2e3;

import java.util.Scanner;

public class Principal {

	public static void main(String[] args) {

		Scanner tamanho = new Scanner(System.in);
		System.out.println("Quantos termos possui a PA? ");
		int t = tamanho.nextInt();

		int vet[] = new int[t];

		for (int i = 0; i < vet.length; i++) {
			Scanner termos = new Scanner(System.in);
			System.out.println("Digite o " + (i + 1) + " termo da PA: ");
			int te = termos.nextInt();
			vet[i] = te;
			
		}

		Scanner numeroN = new Scanner(System.in);
		System.out.println("Digite a posição N do número que deseja ver: ");
		int n = numeroN.nextInt();
		
		double razao = (vet[2] - vet[1]);

		System.out.println("Primeiro termo da PA: " + vet[0]);
		System.out.println("Razão da PA: " + razao);
		System.out.println("N-ésimo termo " + vet[n]);
	}
}
