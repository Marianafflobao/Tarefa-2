package t2e2;

import java.util.Scanner;

public class Principal {

	public static void main(String[] args) {

		Scanner pressao = new Scanner(System.in);
		System.out.println("Qual a pressão do pneu? ");
		double p = pressao.nextDouble();

		Scanner volume = new Scanner(System.in);
		System.out.println("Qual o volume do pneu? ");
		double v = volume.nextDouble();

		Scanner temperatura = new Scanner(System.in);
		System.out.println("Qual a temperatura do pneu? ");
		double t = temperatura.nextDouble();

		double massa = (((p * v) / (t + 460)) / (0.37));

		System.out.println("A massa de ar do pneu é: " + massa);

	}

}
