package t2e1;

import java.util.Scanner;

public class Principal {

	public static void main(String[] args) {
		
		Scanner farenheit = new Scanner (System.in);
		System.out.println("Qual a temperatura em Farenheit? ");
		double F = farenheit.nextDouble();
		double conversaoC = (((5*F)/9) -((5*32)/9));
		
		System.out.println("A temperatura convertida para Celsius é: "+conversaoC);

 }
}

